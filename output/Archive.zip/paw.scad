// ── Footprint 3-D model  ──────────────────────────────
// Physical size : 80.0 mm W  x  113.4 mm H
// Emboss depth  : 8.0 mm     Base: 2.0 mm
// Grid          : 112 x 158 px  (0.714 x 0.717 mm/px)
// Render:  openscad -o model.stl paw.scad
// ─────────────────────────────────────────────────────────────

scale([0.714286, 0.717489, 1])
  surface(file = "paw_heights.dat", center = true, convexity = 10);
